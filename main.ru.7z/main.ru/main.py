print ('Задача "Длина слова"')
print(len('living water'))         # This is a sample
print ('Задача "Суммы и разности"')
first = 5
second = 2
summa = first + second
diff = first - second
print (summa)
print (diff)
print ('Задача "Среднее арифметическое"')
first = 5
second = 2
third = 1
mean = (first + second + third) / 3
print (mean)
print ('Задача "Простые строчки"')
first_string = ('Понедельник')
second_string = ('Вторник')
print (first_string + ',' + second_string)
print ('Задача "Сложная формула"')
a = 5
b = 2
c = 1
f = (((a*b) + (a*c)) ** 3)/2
print (f)
# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
